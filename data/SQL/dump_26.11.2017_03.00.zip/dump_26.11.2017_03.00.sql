-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 26 2017 г., 02:01
-- Версия сервера: 10.2.7-MariaDB
-- Версия PHP: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `hello_world`
--

-- --------------------------------------------------------

--
-- Структура таблицы `hw_emails`
--

CREATE TABLE `hw_emails` (
  `emailId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `flags` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `fromUrl` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `senderName` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `senderEmail` varchar(255) NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `readed` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `hw_emails`
--

INSERT INTO `hw_emails` (`emailId`, `typeId`, `flags`, `fromUrl`, `senderName`, `senderEmail`, `subject`, `message`, `date`, `readed`) VALUES
(1, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(2, 1, 'a:1:{i:0;i:1;}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:26', 1),
(3, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:27', 1),
(5, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:28', 1),
(6, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:29', 1),
(7, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:30', 1),
(8, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:30', 1),
(9, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:31', 1),
(10, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:32', 1),
(11, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:32', 1),
(12, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:33', 1),
(13, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:33', 1),
(14, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:34', 1),
(15, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:34', 1),
(19, 1, 'a:1:{i:4;b:1;}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:37', 0),
(20, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок 1', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:37', 0),
(22, 1, 'a:1:{i:0;b:1;}', '<a href=\"/\">Главная</a>', 'system::message', 'system::message', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:39', 1),
(23, 1, 'a:2:{i:0;b:1;i:1;b:1;}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:39', 0),
(26, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(27, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(28, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(29, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(30, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(31, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(32, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(33, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(34, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(35, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(36, 1, 'a:0:{}', '<a href=\"/\">Главная</a>', 'Иванов Иван Иваныч', 'test.mail@test.ru', 'Заголовок', 'Текст сообщения\n\n  * Тут о чем-то пишут\n  * И еще\n\nИ т.д. и т.п.\nвот))', '2016-02-02 10:09:25', 1),
(38, 2, 'a:1:{i:2;b:1;}', 'http://lit.loc/pages/test_page', 'Владислав', 'test@test.ru', 'Тест формы обратной связи', 'Сообщение для формы обратной связи\n\n----------------------------\nEmail: <a href=\"mailto:test@test.ru\">test@test.ru</a>Телефон: <a href=\"tel:+79121234567\">+7 (912) 123-45-67</a>', '2016-02-03 15:23:36', 1),
(41, 4, 'a:1:{i:4;b:1;}', 'http://lit.loc/admin/news', 'system::message', 'system::message', 'Ошибка на сайте Запчасти для иномарок в Саратове.', '<h1>Произошла ошибка</h1>\n<h2>Произошла ошибка во время выполнения. Пожалуйста, повторите попытку позже.</h2>\n<hr/><h2>Дополнительная информация:</h2>\n<h3>Doctrine\\DBAL\\Exception\\TableNotFoundException</h3>\n<dl>\n<dt>Файл:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">/var/www/cms-skeleton-application/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/AbstractMySQLDriver.php :53</pre>\n</dd>\n<dt>Сообщение:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">An exception occurred while executing &#039;SELECT t0.newsId AS newsId_1, t0.alias AS alias_2, t0.name AS name_3, t0.contentPreview AS contentPreview_4, t0.content AS content_5, t0.date AS date_6, t0.active AS active_7 FROM lit_news t0&#039;:\n\nSQLSTATE[42S02]: Base table or view not found: 1146 Table &#039;lit_db.lit_news&#039; doesn&#039;t exist</pre>\n</dd>\n<dt>Развертывание стека:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">#0 /var/www/cms-skeleton-application/vendor/doctrine/dbal/lib/Doctrine/DBAL/DBALException.php(116): Doctrine\\DBAL\\Driver\\AbstractMySQLDriver-&gt;convertException(&#039;An exception oc...&#039;, Object(Doctrine\\DBAL\\Driver\\PDOException))\n#1 /var/www/cms-skeleton-application/vendor/doctrine/dbal/lib/Doctrine/DBAL/Connection.php(836): Doctrine\\DBAL\\DBALException::driverExceptionDuringQuery(Object(Doctrine\\DBAL\\Driver\\PDOMySql\\Driver), Object(Doctrine\\DBAL\\Driver\\PDOException), &#039;SELECT t0.newsI...&#039;, Array)\n#2 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/Persisters/Entity/BasicEntityPersister.php(884): Doctrine\\DBAL\\Connection-&gt;executeQuery(&#039;SELECT t0.newsI...&#039;, Array, Array)\n#3 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/EntityRepository.php(181): Doctrine\\ORM\\Persisters\\Entity\\BasicEntityPersister-&gt;loadAll(Array, NULL, NULL, NULL)\n#4 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/EntityRepository.php(164): Doctrine\\ORM\\EntityRepository-&gt;findBy(Array)\n#5 /var/www/cms-skeleton-application/module/News/src/News/Controller/AdminController.php(12): Doctrine\\ORM\\EntityRepository-&gt;findAll()\n#6 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Controller/AbstractActionController.php(82): News\\Controller\\AdminController-&gt;indexAction()\n#7 [internal function]: Zend\\Mvc\\Controller\\AbstractActionController-&gt;onDispatch(Object(Zend\\Mvc\\MvcEvent))\n#8 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(490): call_user_func(Array, Object(Zend\\Mvc\\MvcEvent))\n#9 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(263): Zend\\EventManager\\EventManager-&gt;triggerListeners(&#039;dispatch&#039;, Object(Zend\\Mvc\\MvcEvent), Object(Closure))\n#10 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Controller/AbstractController.php(118): Zend\\EventManager\\EventManager-&gt;triggerEventUntil(Object(Closure), Object(Zend\\Mvc\\MvcEvent))\n#11 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/DispatchListener.php(114): Zend\\Mvc\\Controller\\AbstractController-&gt;dispatch(Object(Zend\\Http\\PhpEnvironment\\Request), Object(Zend\\Http\\PhpEnvironment\\Response))\n#12 [internal function]: Zend\\Mvc\\DispatchListener-&gt;onDispatch(Object(Zend\\Mvc\\MvcEvent))\n#13 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(490): call_user_func(Array, Object(Zend\\Mvc\\MvcEvent))\n#14 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(263): Zend\\EventManager\\EventManager-&gt;triggerListeners(&#039;dispatch&#039;, Object(Zend\\Mvc\\MvcEvent), Object(Closure))\n#15 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Application.php(340): Zend\\EventManager\\EventManager-&gt;triggerEventUntil(Object(Closure), Object(Zend\\Mvc\\MvcEvent))\n#16 /var/www/cms-skeleton-application/public/index.php(22): Zend\\Mvc\\Application-&gt;run()\n#17 {main}</pre>\n</dd>\n</dl>\n<hr/>\n<h2>Предыдущие исключения:</h2>\n<ul class=\"unstyled\">\n<li>\n<h3>Doctrine\\DBAL\\Driver\\PDOException</h3>\n<dl>\n<dt>Файл:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">/var/www/cms-skeleton-application/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/PDOConnection.php:106</pre>\n</dd>\n<dt>Сообщение:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">SQLSTATE[42S02]: Base table or view not found: 1146 Table &#039;lit_db.lit_news&#039; doesn&#039;t exist</pre>\n</dd>\n<dt>Развертывание стека:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">#0 /var/www/cms-skeleton-application/vendor/doctrine/dbal/lib/Doctrine/DBAL/Connection.php(833): Doctrine\\DBAL\\Driver\\PDOConnection-&gt;query(&#039;SELECT t0.newsI...&#039;)\n#1 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/Persisters/Entity/BasicEntityPersister.php(884): Doctrine\\DBAL\\Connection-&gt;executeQuery(&#039;SELECT t0.newsI...&#039;, Array, Array)\n#2 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/EntityRepository.php(181): Doctrine\\ORM\\Persisters\\Entity\\BasicEntityPersister-&gt;loadAll(Array, NULL, NULL, NULL)\n#3 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/EntityRepository.php(164): Doctrine\\ORM\\EntityRepository-&gt;findBy(Array)\n#4 /var/www/cms-skeleton-application/module/News/src/News/Controller/AdminController.php(12): Doctrine\\ORM\\EntityRepository-&gt;findAll()\n#5 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Controller/AbstractActionController.php(82): News\\Controller\\AdminController-&gt;indexAction()\n#6 [internal function]: Zend\\Mvc\\Controller\\AbstractActionController-&gt;onDispatch(Object(Zend\\Mvc\\MvcEvent))\n#7 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(490): call_user_func(Array, Object(Zend\\Mvc\\MvcEvent))\n#8 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(263): Zend\\EventManager\\EventManager-&gt;triggerListeners(&#039;dispatch&#039;, Object(Zend\\Mvc\\MvcEvent), Object(Closure))\n#9 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Controller/AbstractController.php(118): Zend\\EventManager\\EventManager-&gt;triggerEventUntil(Object(Closure), Object(Zend\\Mvc\\MvcEvent))\n#10 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/DispatchListener.php(114): Zend\\Mvc\\Controller\\AbstractController-&gt;dispatch(Object(Zend\\Http\\PhpEnvironment\\Request), Object(Zend\\Http\\PhpEnvironment\\Response))\n#11 [internal function]: Zend\\Mvc\\DispatchListener-&gt;onDispatch(Object(Zend\\Mvc\\MvcEvent))\n#12 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(490): call_user_func(Array, Object(Zend\\Mvc\\MvcEvent))\n#13 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(263): Zend\\EventManager\\EventManager-&gt;triggerListeners(&#039;dispatch&#039;, Object(Zend\\Mvc\\MvcEvent), Object(Closure))\n#14 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Application.php(340): Zend\\EventManager\\EventManager-&gt;triggerEventUntil(Object(Closure), Object(Zend\\Mvc\\MvcEvent))\n#15 /var/www/cms-skeleton-application/public/index.php(22): Zend\\Mvc\\Application-&gt;run()\n#16 {main}</pre>\n</dd>\n</dl>\n</li>\n<li>\n<h3>PDOException</h3>\n<dl>\n<dt>Файл:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">/var/www/cms-skeleton-application/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/PDOConnection.php:104</pre>\n</dd>\n<dt>Сообщение:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">SQLSTATE[42S02]: Base table or view not found: 1146 Table &#039;lit_db.lit_news&#039; doesn&#039;t exist</pre>\n</dd>\n<dt>Развертывание стека:</dt>\n<dd>\n<pre class=\"prettyprint linenums\">#0 /var/www/cms-skeleton-application/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/PDOConnection.php(104): PDO-&gt;query(&#039;SELECT t0.newsI...&#039;)\n#1 /var/www/cms-skeleton-application/vendor/doctrine/dbal/lib/Doctrine/DBAL/Connection.php(833): Doctrine\\DBAL\\Driver\\PDOConnection-&gt;query(&#039;SELECT t0.newsI...&#039;)\n#2 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/Persisters/Entity/BasicEntityPersister.php(884): Doctrine\\DBAL\\Connection-&gt;executeQuery(&#039;SELECT t0.newsI...&#039;, Array, Array)\n#3 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/EntityRepository.php(181): Doctrine\\ORM\\Persisters\\Entity\\BasicEntityPersister-&gt;loadAll(Array, NULL, NULL, NULL)\n#4 /var/www/cms-skeleton-application/vendor/doctrine/orm/lib/Doctrine/ORM/EntityRepository.php(164): Doctrine\\ORM\\EntityRepository-&gt;findBy(Array)\n#5 /var/www/cms-skeleton-application/module/News/src/News/Controller/AdminController.php(12): Doctrine\\ORM\\EntityRepository-&gt;findAll()\n#6 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Controller/AbstractActionController.php(82): News\\Controller\\AdminController-&gt;indexAction()\n#7 [internal function]: Zend\\Mvc\\Controller\\AbstractActionController-&gt;onDispatch(Object(Zend\\Mvc\\MvcEvent))\n#8 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(490): call_user_func(Array, Object(Zend\\Mvc\\MvcEvent))\n#9 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(263): Zend\\EventManager\\EventManager-&gt;triggerListeners(&#039;dispatch&#039;, Object(Zend\\Mvc\\MvcEvent), Object(Closure))\n#10 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Controller/AbstractController.php(118): Zend\\EventManager\\EventManager-&gt;triggerEventUntil(Object(Closure), Object(Zend\\Mvc\\MvcEvent))\n#11 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/DispatchListener.php(114): Zend\\Mvc\\Controller\\AbstractController-&gt;dispatch(Object(Zend\\Http\\PhpEnvironment\\Request), Object(Zend\\Http\\PhpEnvironment\\Response))\n#12 [internal function]: Zend\\Mvc\\DispatchListener-&gt;onDispatch(Object(Zend\\Mvc\\MvcEvent))\n#13 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(490): call_user_func(Array, Object(Zend\\Mvc\\MvcEvent))\n#14 /var/www/cms-skeleton-application/vendor/zendframework/zend-eventmanager/src/EventManager.php(263): Zend\\EventManager\\EventManager-&gt;triggerListeners(&#039;dispatch&#039;, Object(Zend\\Mvc\\MvcEvent), Object(Closure))\n#15 /var/www/cms-skeleton-application/vendor/zendframework/zend-mvc/src/Application.php(340): Zend\\EventManager\\EventManager-&gt;triggerEventUntil(Object(Closure), Object(Zend\\Mvc\\MvcEvent))\n#16 /var/www/cms-skeleton-application/public/index.php(22): Zend\\Mvc\\Application-&gt;run()\n#17 {main}</pre>\n</dd>\n</dl>\n</li>\n</ul>\n', '2016-03-03 21:22:29', 1),
(45, 4, 'a:1:{i:4;b:1;}', 'http://lit.loc/asd', 'system::message', 'system::message', 'Ошибка 404 на сайте Запчасти для иномарок в Саратове.', '<h1>Ошибка 404</h1>\n<h2>Page not found.</h2>\n<p>Запрашиваемый контроллер не смог отправить запрос.</p>\n<dl>\n<dt>Контроллер:</dt>\n<dd>Files\\Controller\\Index\n</dd>\n</dl>\n<h3>Нет имеющихся исключений</h3>\n', '2016-03-03 22:01:48', 1),
(46, 2, 'a:2:{i:0;b:1;i:1;b:1;}', 'http://helloworld.loc/pages/test_page', 'aa', 'iviefistofel@gmail.com', 'test', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n\n----------------------------\nEmail: <a href=\"mailto:iviefistofel@gmail.com\">iviefistofel@gmail.com</a>\nТелефон: <a href=\"tel:+9124632165\">9124632165</a>', '2017-11-26 00:33:55', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `hw_fields`
--

CREATE TABLE `hw_fields` (
  `fieldID` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_fields`
--

INSERT INTO `hw_fields` (`fieldID`, `name`, `alias`, `description`, `type`) VALUES
(1, 'Заголовок страницы (title)', 'seo_title', '', 'input'),
(2, 'Ключевые слова (keywords)', 'seo_keywords', '', 'input'),
(3, 'Описание страницы (description)', 'seo_description', '', 'input'),
(4, 'Файл', 'file', '', 'file'),
(5, 'Изображение', 'image', '', 'image'),
(6, 'Галлерея', 'gallery', '', 'gallery'),
(8, 'Схема проезда', 'map', '', 'image'),
(9, 'Логотип', 'logo', '', 'image'),
(10, 'Название формы', 'form_name', '', 'input'),
(11, 'Контент формы', 'form', '', 'textarea');

-- --------------------------------------------------------

--
-- Структура таблицы `hw_fields_values`
--

CREATE TABLE `hw_fields_values` (
  `fieldID` int(11) NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_fields_values`
--

INSERT INTO `hw_fields_values` (`fieldID`, `alias`, `value`) VALUES
(1, 'test_page', 'Заголовок Тестовой страницы'),
(2, 'test_page', 'Ключевые слова Тестовой страницы'),
(3, 'test_page', 'Описание Тестовой страницы'),
(5, 'images/test/first.jpg', './upload/php6F1_5a19be41653305_66360688.tmp'),
(10, 'feedback_form', 'Форма обратной связи'),
(11, 'feedback_form', '<form class=\"pure-form pure-form-aligned\" action=\"/forms\" method=\"post\">\r\n	<input type=\"hidden\" name=\"form-type\" value=\"feedback-form\">\r\n	<div class=\"pure-control-group\">\r\n		<label for=\"feedback-name\">Имя</label>\r\n		<input id=\"feedback-name\" name=\"feedback-name\" type=\"text\" class=\"pure-input-1-2\"  placeholder=\"Имя\" required=\"required\">\r\n	</div>\r\n	<div class=\"pure-control-group\">\r\n		<label for=\"feedback-email\">Email</label>\r\n		<input id=\"feedback-email\" name=\"feedback-email\" type=\"email\" class=\"pure-input-1-2\"  placeholder=\"Email\" required=\"required\">\r\n	</div>\r\n	<div class=\"pure-control-group\">\r\n		<label for=\"feedback-phone\">Телефон</label>\r\n		<input id=\"feedback-phone\" name=\"feedback-phone\" type=\"text\" class=\"pure-input-1-2\"  placeholder=\"+7 (912) 123-45-67\" required=\"required\">\r\n	</div>\r\n	<div class=\"pure-control-group\">\r\n		<label for=\"feedback-subject\">Тема сообщения</label>\r\n		<input id=\"feedback-subject\" name=\"feedback-subject\" type=\"text\" class=\"pure-input-1-2\"  placeholder=\"Тема сообщения\">\r\n	</div>\r\n	<div class=\"pure-control-group\">\r\n		<label for=\"feedback-message\">Текст сообщения</label>\r\n		<textarea id=\"feedback-message\" name=\"feedback-message\" class=\"pure-input-1-2\" rows=\"5\"  placeholder=\"Сообщение...\" required=\"required\"></textarea>\r\n	</div>\r\n	<div class=\"pure-controls\">\r\n		<input type=\"submit\" class=\"pure-button pure-button-primary\" value=\"Отправить\">\r\n	</div>\r\n</form>');

-- --------------------------------------------------------

--
-- Структура таблицы `hw_menu`
--

CREATE TABLE `hw_menu` (
  `menuId` int(11) NOT NULL,
  `menuLabel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `menuURL` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `menuActive` tinyint(1) NOT NULL,
  `menuWeight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_menu`
--

INSERT INTO `hw_menu` (`menuId`, `menuLabel`, `menuURL`, `menuActive`, `menuWeight`) VALUES
(1, 'Главная', '/', 1, 1),
(2, 'Каталог', '/catalog', 1, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `hw_news`
--

CREATE TABLE `hw_news` (
  `newsId` int(11) NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contentPreview` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_news`
--

INSERT INTO `hw_news` (`newsId`, `alias`, `name`, `contentPreview`, `content`, `date`, `active`) VALUES
(1, 'test_news_1', 'Test news', '<div class=\"article-content\">\r\n<p><span style=\"font-size: medium;\">Следом за новым серийным электро <span style=\"color: #181818; line-height: 26px;\">кабриолетом от <span style=\"color: #000000; font-size: medium; line-height: 20px;\"><strong>Citroen</strong>, компания представит серийный коммерческий фургон <span style=\"color: #000000; font-size: medium; line-height: 20px;\">SpaceTourer, которому сделали специально для концепт версии, яркий футуристический дизайн, что бы привлечь к себе больше внимания, будут установлены пластиковые детали и обвесы. </span></span></span></span></p>\r\n<p><img src=\"http://vin64.ru/images/2036430.jpg\" border=\"0\">\r\n</p></div>', '<div class=\"article-content\">\r\n<p><span style=\"font-size: medium;\">Следом за новым серийным электро <span style=\"color: #181818; line-height: 26px;\">кабриолетом от <span style=\"color: #000000; font-size: medium; line-height: 20px;\"><strong>Citroen</strong>, компания представит серийный коммерческий фургон <span style=\"color: #000000; font-size: medium; line-height: 20px;\">SpaceTourer, которому сделали специально для концепт версии, яркий футуристический дизайн, что бы привлечь к себе больше внимания, будут установлены пластиковые детали и обвесы. </span></span></span></span></p>\r\n<p><img src=\"http://vin64.ru/images/2036430.jpg\" border=\"0\">\r\n\r\n\r\n\r\n</p>\r\n<p><span style=\"font-size: medium;\">Силовая установка <span style=\"color: #000000; line-height: 20px;\"><strong>Citroen</strong></span> </span><span style=\"color: #000000; font-size: medium; line-height: 20px;\">SpaceTourer, дизельный двигатель в 150 л.с. <span style=\"color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; line-height: 20px;\"><span style=\"font-size: medium;\">BlueHDi S&S. Установлена шести ступенчатая механическая коробка передач и полный привод который разработан в <span style=\"color: #000000; line-height: 20px;\">сотрудничестве с Automobiles Dangel. </span></span></span></span></p>\r\n<p><img src=\"http://vin64.ru/images/2036434.jpg\" border=\"0\"></p>\r\n<p><span style=\"font-size: medium;\">тэги: <a href=\"http://vin64.ru/katalog.html\">запчасти для иномарок в Саратове</a>, <a href=\"http://vin64.ru/citroen-/-sitroen/view-all-products.html\">запчасти для CITROEN / СИТРОЕН в Саратове</a>, <a href=\"http://vin64.ru/contacts.html\">запчасти для иномарок Саратов</a>.</span></p></div>', '2016-03-03', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `hw_pages`
--

CREATE TABLE `hw_pages` (
  `pageID` int(11) NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `formName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_pages`
--

INSERT INTO `hw_pages` (`pageID`, `alias`, `name`, `content`, `formName`, `active`, `date`) VALUES
(1, 'test_page', 'Тестовая страница 1', '<p>К сожалению, такой страницы не существует. Возможно вы набрали неправильный адрес, или перешли на страницу, которая была перемещена или удалена. Попробуйте начать поиск необходимой информации заново с <a href=\"{base_url}\" title=\"Петровский\">главной страницы</a> сайта</p>\r\n<p>К сожалению, такой страницы не существует. Возможно вы набрали неправильный адрес, или перешли на страницу, которая была перемещена или удалена. Попробуйте начать поиск необходимой информации заново с <a href=\"{server_url}{base_url}\" title=\"Петровский\">главной страницы</a> сайта</p>\r\n<p>К сожалению, такой страницы не существует. Возможно вы набрали неправильный адрес, или перешли на страницу, которая была перемещена или удалена. Попробуйте начать поиск необходимой информации заново с <a href=\"{server_url}{base_url}\" title=\"Петровский\">главной страницы</a> сайта</p>\r\n<p>К сожалению, такой страницы не существует. Возможно вы набрали неправильный адрес, или перешли на страницу, которая была перемещена или удалена. Попробуйте начать поиск необходимой информации заново с <a href=\"{server_url}{base_url}\" title=\"Петровский\">главной страницы</a> сайта</p>', 'feedback_form', '1', '2016-01-26 06:04:00');

-- --------------------------------------------------------

--
-- Структура таблицы `hw_sensors`
--

CREATE TABLE `hw_sensors` (
  `sensorID` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL,
  `active` varchar(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_sensors`
--

INSERT INTO `hw_sensors` (`sensorID`, `name`, `description`, `alias`, `weight`, `active`) VALUES
(1, 'Формы для связи', 'Все действия с формами на сайте', 'forms', 1, '1'),
(2, 'Ссылки на скачивание', 'Ссылки на скачивание презентаций и предложений', 'download', 2, '1');

-- --------------------------------------------------------

--
-- Структура таблицы `hw_sensor_calls`
--

CREATE TABLE `hw_sensor_calls` (
  `callID` int(11) NOT NULL,
  `signalID` int(11) NOT NULL,
  `sensorID` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `hw_sensor_signals`
--

CREATE TABLE `hw_sensor_signals` (
  `signalID` int(11) NOT NULL,
  `sensorID` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `mainPageDescription` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL,
  `active` varchar(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_sensor_signals`
--

INSERT INTO `hw_sensor_signals` (`signalID`, `sensorID`, `name`, `description`, `mainPageDescription`, `alias`, `weight`, `active`) VALUES
(1, 1, 'Обратная связь', 'Срабатывает, когда посетитель отправляет отзыв из формы обратной связи.', 'Обратная связь', 'feedback_send', 1, '1'),
(2, 1, 'Заказ', 'Срабатывает, когда посетитель отправляет форму заказа.', 'Заказ', 'order_send', 2, '1');

-- --------------------------------------------------------

--
-- Структура таблицы `hw_settings`
--

CREATE TABLE `hw_settings` (
  `settingID` int(11) NOT NULL,
  `groupID` int(11) NOT NULL,
  `headerName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `htmlControlType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_settings`
--

INSERT INTO `hw_settings` (`settingID`, `groupID`, `headerName`, `name`, `value`, `htmlControlType`, `weight`) VALUES
(1, 1, 'Заголовок сайта', 'main_title', 'Запчасти для иномарок в Саратове', 'input', 1),
(2, 2, 'Эл. адрес для отправки отчетов об ошибках на сайте', 'email_for_error_reporting', 'support@lab-itec.ru', 'input', 1),
(3, 3, 'Тема письма', 'newsletter_theme', 'Рассылка новостей компании {Name} {domain}', 'input', 1),
(4, 3, 'Текст письма', 'newsletter_body', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"ru\" lang=\"ru\">\r\n<head>\r\n	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n	<title>Компания «Фудсервис»</title>	\r\n</head> \r\n<body style=\"background-color: #1A1616; margin: 0; padding: 0;\">\r\n	{newsletter_header}\r\n	{newsletter_text}\r\n	{email_uid}\r\n</body>\r\n</html>', 'textarea', 2),
(5, 4, 'Кнопка Like для Vkontakte', 'social_vk_button_like', '<div id=\"vk_like\"></div>\r\n<script type=\"text/javascript\">\r\n$(document).bind(\"loadVkApiLike\", function(e){\r\n  VK.init({apiId: VK_APP_ID, onlyWidgets: true});\r\n   VK.Widgets.Like(\"vk_like\", {type: \"mini\"});\r\n});\r\n</script>', 'textarea', 1),
(6, 1, 'Включить LockScreen', 'lockscreen_enabled', '0', 'checkbox', 2),
(7, 1, 'Время ожидания LockScreen (сек)', 'lockscreen_timeout', '600', 'input', 3),
(8, 1, 'Включить Яндекс Метрику', 'yandex_metrika_enabled', '0', 'checkbox', 4),
(9, 1, 'ID счетчика Яндекс Метрики', 'yandex_metrika_id', '35121670', 'input', 5),
(10, 1, 'Oauth Token Яндекс Метрики', 'yandex_metrika_token', 'e81174419a1642e08bc15f711c581f6f', 'input', 6),
(11, 1, 'Код счётчика Яндекс Метрики', 'yandex_metrika_javascript', '<!-- Yandex.Metrika counter -->\r\n    <script type=\"text/javascript\">\r\n        (function (d, w, c) {\r\n            (w[c] = w[c] || []).push(function() {\r\n                try {\r\n                    w.yaCounter35121670 = new Ya.Metrika({\r\n                        id:35121670,\r\n                        clickmap:true,\r\n                        trackLinks:true,\r\n                        accurateTrackBounce:true,\r\n                        webvisor:true\r\n                    });\r\n                } catch(e) { }\r\n            });\r\n\r\n            var n = d.getElementsByTagName(\"script\")[0],\r\n                s = d.createElement(\"script\"),\r\n                f = function () { n.parentNode.insertBefore(s, n); };\r\n            s.type = \"text/javascript\";\r\n            s.async = true;\r\n            s.src = \"https://mc.yandex.ru/metrika/watch.js\";\r\n\r\n            if (w.opera == \"[object Opera]\") {\r\n                d.addEventListener(\"DOMContentLoaded\", f, false);\r\n            } else { f(); }\r\n        })(document, window, \"yandex_metrika_callbacks\");\r\n    </script>\r\n    <noscript><div><img src=\"https://mc.yandex.ru/watch/35121670\" style=\"position:absolute; left:-9999px; display: none\" alt=\"\" /></div></noscript>\r\n    <!-- /Yandex.Metrika counter -->', 'textarea', 7),
(12, 1, 'Демо режим Яндекс Метрики', 'yandex_metrika_demo', '1', 'checkbox', 8);

-- --------------------------------------------------------

--
-- Структура таблицы `hw_settings_groups`
--

CREATE TABLE `hw_settings_groups` (
  `groupID` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_settings_groups`
--

INSERT INTO `hw_settings_groups` (`groupID`, `name`, `weight`) VALUES
(1, 'Параметры сайта', 1),
(2, 'Автоматические письма', 2),
(3, 'Рассылка', 3),
(4, 'Социальные кнопки и виджеты', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `hw_users`
--

CREATE TABLE `hw_users` (
  `userId` int(11) NOT NULL,
  `userName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userFullName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userEmail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userPassword` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userRoleId` int(11) NOT NULL,
  `userActive` tinyint(1) NOT NULL,
  `userRegistrationDate` datetime NOT NULL,
  `userEmailConfirmed` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `hw_users`
--

INSERT INTO `hw_users` (`userId`, `userName`, `userFullName`, `userEmail`, `userPassword`, `userRoleId`, `userActive`, `userRegistrationDate`, `userEmailConfirmed`) VALUES
(1, 'Aleksey', 'Слесарев Алексей', 'alekseyslesarev@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1, 1, '2017-11-20 00:00:00', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `hw_emails`
--
ALTER TABLE `hw_emails`
  ADD PRIMARY KEY (`emailId`);

--
-- Индексы таблицы `hw_fields`
--
ALTER TABLE `hw_fields`
  ADD PRIMARY KEY (`fieldID`),
  ADD UNIQUE KEY `alias` (`alias`);

--
-- Индексы таблицы `hw_fields_values`
--
ALTER TABLE `hw_fields_values`
  ADD PRIMARY KEY (`fieldID`,`alias`),
  ADD UNIQUE KEY `fieldID` (`fieldID`,`alias`);

--
-- Индексы таблицы `hw_menu`
--
ALTER TABLE `hw_menu`
  ADD PRIMARY KEY (`menuId`);

--
-- Индексы таблицы `hw_news`
--
ALTER TABLE `hw_news`
  ADD PRIMARY KEY (`newsId`);

--
-- Индексы таблицы `hw_pages`
--
ALTER TABLE `hw_pages`
  ADD PRIMARY KEY (`pageID`);

--
-- Индексы таблицы `hw_sensors`
--
ALTER TABLE `hw_sensors`
  ADD PRIMARY KEY (`sensorID`);

--
-- Индексы таблицы `hw_sensor_calls`
--
ALTER TABLE `hw_sensor_calls`
  ADD PRIMARY KEY (`callID`);

--
-- Индексы таблицы `hw_sensor_signals`
--
ALTER TABLE `hw_sensor_signals`
  ADD PRIMARY KEY (`signalID`);

--
-- Индексы таблицы `hw_settings`
--
ALTER TABLE `hw_settings`
  ADD PRIMARY KEY (`settingID`);

--
-- Индексы таблицы `hw_settings_groups`
--
ALTER TABLE `hw_settings_groups`
  ADD PRIMARY KEY (`groupID`);

--
-- Индексы таблицы `hw_users`
--
ALTER TABLE `hw_users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `hw_emails`
--
ALTER TABLE `hw_emails`
  MODIFY `emailId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT для таблицы `hw_fields`
--
ALTER TABLE `hw_fields`
  MODIFY `fieldID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `hw_menu`
--
ALTER TABLE `hw_menu`
  MODIFY `menuId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `hw_news`
--
ALTER TABLE `hw_news`
  MODIFY `newsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `hw_pages`
--
ALTER TABLE `hw_pages`
  MODIFY `pageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `hw_sensors`
--
ALTER TABLE `hw_sensors`
  MODIFY `sensorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `hw_sensor_calls`
--
ALTER TABLE `hw_sensor_calls`
  MODIFY `callID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `hw_sensor_signals`
--
ALTER TABLE `hw_sensor_signals`
  MODIFY `signalID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `hw_settings`
--
ALTER TABLE `hw_settings`
  MODIFY `settingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `hw_settings_groups`
--
ALTER TABLE `hw_settings_groups`
  MODIFY `groupID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `hw_users`
--
ALTER TABLE `hw_users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
